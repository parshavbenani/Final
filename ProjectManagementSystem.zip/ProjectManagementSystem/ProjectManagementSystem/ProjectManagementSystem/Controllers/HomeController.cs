﻿using FinalTest.Utilities;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using ProjectmanagementSystem.Models;
using ProjectManagementSystem.Models;
using System.Data;
using System.Diagnostics;

namespace ProjectManagementSystem.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly UserManager<Employee> _userManager;
        private readonly SignInManager<Employee> _signInManager;

        public HomeController(ILogger<HomeController> logger,UserManager<Employee> userManager, SignInManager<Employee> signInManager)
        {
            _logger = logger;
            _userManager = userManager;
            _signInManager = signInManager;
        }

        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Index(LoginVM obj)
        {
            if (ModelState.IsValid)
            {
                var user = await _userManager.FindByEmailAsync(obj.Email);
                if (user != null)
                {              
                    var data = await _signInManager.PasswordSignInAsync(user, obj.Password, false, false);
                    var role = await _userManager.GetRolesAsync(user);
                    var currentrole = role.FirstOrDefault();              

                    if (data.Succeeded && role.Any())
                    {
                        if (currentrole == "ProjectManager")
                        {
                            HttpContext.Session.SetString("Uid",user.Id);
                            HttpContext.Session.SetString("Name", user.Name);
                            TempData["success"] = "Login Successfully";
                            return RedirectToAction("Index", "User");
                        }
                        return RedirectToAction("Index","Home");
                    }
                }
            }
            TempData["error"] = "Something Went Wronge";
            return View();
        }


        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}