﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectmanagementSystem.Models
{
    public class ProjectDetailVM
    {
        [Required(ErrorMessage = "Please Enter Project Name")]
        public string ProjectName { get; set; }
        public string ProjectDetail { get; set; }
        public DateTime DeadlineDate { get; set; }
        [Required(ErrorMessage ="Please Select Employee")]
        public List<string> EmployeeName { get; set; }
        [Required(ErrorMessage = "Please Select Project Manager")]
        public string ProjectManagerName { get; set; }
    }
}
