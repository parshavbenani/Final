﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectmanagementSystem.Models
{
    public class Employee : IdentityUser
    {
        public string Name { get; set; }
        public string EmployeeCode { get; set; }
        public DateTime JoiningDate { get; set; }
        public string EmployeeType { get; set; }
    }
}
