﻿using FinalAzure.DataAccess.IRepository;
using FinalAzure.Models.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalAzure
{
    public class GetOrders
    {
        private readonly IOrder _order;

        public GetOrders(IOrder order)
        {
            _order = order;
        }

        [FunctionName("GetOrders")]
        public async Task<response> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {

            try
            {
                OrderFilter order = new OrderFilter();
                var content = await new StreamReader(req.Body).ReadToEndAsync();
                order = JsonConvert.DeserializeObject<OrderFilter>(content);

                return await _order.GetFilterdOrders(order);
            }
            catch (Exception ex)
            {
                return new response { Data = ex.Message.ToString(), Message = "Exception", Status = "Error" };
            }
        }
    }
}
