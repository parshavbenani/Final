﻿using FinalAzure.DataAccess.IRepository;
using FinalAzure.Models.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalAzure
{
    public class UpdateOrderStatus
    {
        private readonly IOrder _order;

        public UpdateOrderStatus(IOrder order)
        {
            _order = order;
        }

        [FunctionName("UpdateOrderStatus")]
        public async Task<response> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            try
            {
                int orderId = int.Parse(req.Query["orderId"]);
                Global.status status = (Global.status)Enum.Parse(typeof(Global.status), (req.Query["status"]));
                return await _order.UpdateStatus(OrderId: orderId, status: status);
            }
            catch (Exception ex)
            {
                return new response { Data = ex.Message.ToString(), Message = "Exception", Status = "Error" };
            }
        }
    }
}
