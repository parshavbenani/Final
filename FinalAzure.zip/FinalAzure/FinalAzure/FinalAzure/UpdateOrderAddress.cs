﻿using FinalAzure.DataAccess.IRepository;
using FinalAzure.Models.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalAzure
{
    public class UpdateOrderAddress
    {
        private readonly IAddress _address;
        public UpdateOrderAddress(IAddress address)
        {
            _address = address;
        }
        [FunctionName("UpdateOrderAddress")]
        public async Task<response> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            try
            {
                //1 for Shipping
                //2 for billing
                UpdateAddressDto UpdateAddress = new UpdateAddressDto();
                var content = await new StreamReader(req.Body).ReadToEndAsync();
                UpdateAddress = JsonConvert.DeserializeObject<UpdateAddressDto>(content);

                return await _address.UpdateOrderAddress(UpdateAddress);
            }
            catch (Exception ex)
            {
                return new response { Data = ex.Message.ToString(), Message = "Exception", Status = "Error" };
            }
        }
    }
}
