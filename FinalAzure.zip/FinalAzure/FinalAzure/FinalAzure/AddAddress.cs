﻿using FinalAzure.DataAccess.IRepository;
using FinalAzure.Models.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalAzure
{
    public class AddAddress
    {
        private readonly IAddress _address;
        public AddAddress(IAddress address)
        {
            _address = address;
        }

        [FunctionName("AddAddress")]
        public async Task<response> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            AddAddressViewModel address = new AddAddressViewModel();                 //Create Object 
         
            var content = await new StreamReader(req.Body).ReadToEndAsync();        //Store Json Body Data in content 
            address = JsonConvert.DeserializeObject<AddAddressViewModel>(content);  // Json data store in AddAddressViewModel
            return await _address.AddAddressForUser(address);

        }
    }
}
