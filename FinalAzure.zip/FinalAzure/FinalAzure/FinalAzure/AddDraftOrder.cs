﻿using FinalAzure.DataAccess.IRepository;
using FinalAzure.Models.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalAzure
{
    public class AddDraftOrder
    {
        private readonly IOrder _order;
        public AddDraftOrder(IOrder order)
        {
            _order = order;
        }


        [FunctionName("DraftOrder")]
        public async Task<response> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req,
            ILogger log)
        {

            try
            {
                DraftOrder order = new DraftOrder();
                var content = await new StreamReader(req.Body).ReadToEndAsync();
                order = JsonConvert.DeserializeObject<DraftOrder>(content);

                return await _order.AddDraftOrder(order);
            }
            catch (Exception ex)
            {
                return new response { Data = ex.Message.ToString(), Message = "Exception", Status = "Error" };
            }
        }
    }
}
