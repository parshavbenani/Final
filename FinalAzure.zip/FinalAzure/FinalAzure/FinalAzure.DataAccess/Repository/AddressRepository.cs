﻿using FinalAzure.DataAccess.Data;
using FinalAzure.DataAccess.IRepository;
using FinalAzure.Models.Models;
using FinalAzure.Models.ViewModels;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalAzure.DataAccess.Repository
{
    public class AddressRepository : IAddress
    {
        private readonly ApplicationDbContext _dbContext;
        public AddressRepository(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<response> GetAddressList(string email)
        {
            try
            {
                response response = new response();
                response.Data = await _dbContext.Address.Where(x => x.ContactEmail == email).ToListAsync();
                if(response.Data.Count == 0)
                {
                    response.Status = "True";
                    response.Message = "Data Not Found";
                }
                else
                {
                    response.Status = "True";
                    response.Message = "Success";
                }               
                return response;
            }
            catch (Exception ex)
            {
                return new response { Data = ex.Message.ToString(), Message = "Exception", Status = "Error" };
            }
        }

        public async Task<response> AddAddressForUser(AddAddressViewModel address)
        {
            try
            {
                response response = new response();
                var UserExist = await _dbContext.aspnetusers.Where(x => x.Id == address.userId).ToListAsync();
                if (UserExist.Any() && UserExist.Count == 1)
                {
                    var isEmailExist = _dbContext.Address.Where(x => x.ContactEmail == address.ContactEmail && (x.AddressType == Global.AddressType.Billing && x.AddressType == address.AddressType)).ToList();
                    if (isEmailExist.Count >= 1)
                    {
                        return new response { Data = "", Message = "Billing Address cannot be add more than 1", Status = "Error" };
                    }
                    address add = new address()
                    {
                        Country = address.Country,
                        State = address.State,
                        City = address.City,
                        HouseNo = address.HouseNo,
                        ZipCode = int.Parse(address.ZipCode),
                        ContactNo = address.ContactNo,
                        ContactPerson = address.ContactPerson,
                        AddressType = address.AddressType,
                        userId = address.userId,
                        ContactEmail = address.ContactEmail,
                    };
                    await _dbContext.Address.AddAsync(add);
                    _dbContext.SaveChanges();
                    response.Data = "";
                    response.Status = "Success";
                    response.Message = "Data Added Successfully";
                    return response;
                }
                else
                {
                    return new response { Data = "", Message = "No User found with this userId", Status = "Error" };
                }
            }
            catch (Exception ex)
            {
                return new response { Data = ex.Message.ToString(), Message = "Exception", Status = "Error" };
            }
        }



        public async Task<response> UpdateOrderAddress(UpdateAddressDto UpdateAddress) 
        {
            try
            {
                var isDataExist = _dbContext.OrderAddress.Where(x => x.OrderAddId == UpdateAddress.OrderAddressId).FirstOrDefault();
                address addressObj = new address();
                if (UpdateAddress.AddressChangeType == Global.AddressType.Billing)
                {
                    addressObj = _dbContext.Address.Where(x => x.AddressType == Global.AddressType.Billing && x.AddressId == isDataExist.BillingAddressId).First();
                }
                else
                {
                    addressObj = _dbContext.Address.Where(x => x.AddressType == Global.AddressType.Shipping && x.AddressId == isDataExist.ShippingAddressId).First();
                }

                addressObj.HouseNo = UpdateAddress.Address.HouseNo;
                addressObj.Country = UpdateAddress.Address.Country;
                addressObj.State = UpdateAddress.Address.State;
                addressObj.City = UpdateAddress.Address.City;
                addressObj.ZipCode = int.Parse(UpdateAddress.Address.ZipCode);
                addressObj.ContactPerson = UpdateAddress.Address.ContactPerson;
                addressObj.ContactEmail = UpdateAddress.Address.ContactEmail;
                addressObj.ContactNo = UpdateAddress.Address.ContactNo;

                _dbContext.Address.Update(addressObj);
                _dbContext.SaveChanges();
                return new response { Data = "", Message = "Address Updated Successfully", Status = "Success" };
            }
            catch (Exception ex)
            {
                return new response { Data = ex.Message.ToString(), Message = "Something is Wrong!!!", Status = "Error" };
            }

        }
    }
}
