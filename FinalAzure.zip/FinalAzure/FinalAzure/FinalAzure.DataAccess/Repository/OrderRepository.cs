﻿using FinalAzure.DataAccess.Data;
using FinalAzure.DataAccess.IRepository;
using FinalAzure.Models.Models;
using FinalAzure.Models.ViewModels;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalAzure.DataAccess.Repository
{
    public class OrderRepository : IOrder
    {
        private readonly ApplicationDbContext _context;
        public OrderRepository(ApplicationDbContext context)
        {
            _context = context;
        }


        //Update Order-Status
        public async Task<response> UpdateStatus(int OrderId, Global.status status)
        {
            try
            {
                response response = new response();
                var currentStatus = getStatus(OrderId);     // call getStatus Fun. to get Status

                //if status is shipped than status can only change as paid
                if (currentStatus == Global.status.Shipped)
                {
                    if (status == Global.status.Paid)
                    {
                        return UpdateStatusOnDb(OrderId, status);
                    }
                    else
                    {
                        return new response { Data = "", Message = "Status Cannot update,Bec. Shipped status Updated only as Paid", Status = "Error" };
                    }
                }
                //if status is paid than status can not change
                else if (currentStatus == Global.status.Paid)
                {
                    return new response { Data = "", Message = "Status Cannot update,Bec.Order status already Paid", Status = "Error" };
                }
                else
                {
                    return UpdateStatusOnDb(OrderId, status);
                }
            }
            catch (Exception ex)
            {
                return new response { Data = ex.Message.ToString(), Message = "Exception", Status = "Error" };
            }
        }


        //To get order.status of orderId
        private Global.status getStatus(int id)
        {
            var orders = _context.Orders.Where(x => x.OrderId == id).FirstOrDefault();
            if (orders == null)
            {
                throw new Exception("No Order found with this orderId");
            }
            Global.status status = new Global.status();
            status = orders.StatusType;
            return status;
        }


        //Add DraftOrder
        public async Task<response> AddDraftOrder(DraftOrder draftOrder)
        {
            try
            {
                int total = 0;
                var UserExist = _context.aspnetusers.Where(x => x.Email == draftOrder.BillingAddress.ContactEmail).ToList();
                if (UserExist.Any())
                {
                    return new response { Data = "", Message = "User already exist with this email", Status = "Error" };
                }

                //Calculating Product-item total
                foreach (var item in draftOrder.Products)
                {
                    var isProductExist = _context.Products.Where(x => x.ProductId == item.ProductId).ToList();
                    if (isProductExist.Any())
                    {
                        if (isProductExist.FirstOrDefault().ProductQty != 0 || isProductExist.FirstOrDefault().ProductQty >= item.ProductQty)
                        {
                            total += isProductExist.FirstOrDefault().ProductPrice * item.ProductQty;
                        }
                        else
                        {
                            return new response { Data = "", Message = "Enter valid Quantity for this Product", Status = "Error" };
                        }
                    }
                    else
                    {
                        return new response { Data = "", Message = "Product Does't found with this ProductId", Status = "Error" };
                    }
                }

                Console.WriteLine(total);

                //Creating order
                var order = new Order()
                {
                    OrderDate = DateTime.Now,
                    Note = draftOrder.Note,
                    DisountAmount = draftOrder.DisountAmount,
                    StatusType = Global.status.Open,
                    CustomerName = draftOrder.BillingAddress.ContactPerson,
                    CustomerEmail = draftOrder.BillingAddress.ContactEmail,
                    CustomerContactNo = draftOrder.BillingAddress.ContactNo,
                    IsActive = draftOrder.IsActive,
                    TotalAmount = total,
                    CreatedOn = DateTime.Now
                };
                await _context.Orders.AddAsync(order);
                _context.SaveChanges();

                //Creating orderItem
                var getOrder = _context.Orders.Where(x => x.CustomerEmail == draftOrder.BillingAddress.ContactEmail).FirstOrDefault();
                if (getOrder != null)
                {
                    int id = getOrder.OrderId;
                    foreach (var item in draftOrder.Products)
                    {
                        var orderItem = new OrderItem()
                        {
                            Qty = item.ProductQty,
                            OrderId = id,
                            ProductId = item.ProductId,
                            isActive = draftOrder.IsActive,
                            price = _context.Products.Where(x => x.ProductId == item.ProductId).FirstOrDefault().ProductPrice
                        };
                        await _context.OrderItems.AddAsync(orderItem);
                        _context.SaveChanges();
                    }
                }

                //Creating Billing Address
                var bAddress = new address()
                {
                    HouseNo = draftOrder.BillingAddress.HouseNo,
                    Country = draftOrder.BillingAddress.Country,
                    State = draftOrder.BillingAddress.State,
                    City = draftOrder.BillingAddress.City,
                    ZipCode = int.Parse(draftOrder.BillingAddress.ZipCode),
                    ContactPerson = draftOrder.BillingAddress.ContactPerson,
                    ContactEmail = draftOrder.BillingAddress.ContactEmail,
                    ContactNo = draftOrder.BillingAddress.ContactNo,
                    AddressType = Global.AddressType.Billing
                };
                await _context.Address.AddAsync(bAddress);
                _context.SaveChanges();

                //Creating Shipping Address
                var sAddress = new address()
                {
                    HouseNo = draftOrder.ShippingAddress.HouseNo,
                    Country = draftOrder.ShippingAddress.Country,
                    State = draftOrder.ShippingAddress.State,
                    City = draftOrder.ShippingAddress.City,
                    ZipCode = int.Parse(draftOrder.ShippingAddress.ZipCode),
                    ContactPerson = draftOrder.ShippingAddress.ContactPerson,
                    ContactEmail = draftOrder.ShippingAddress.ContactEmail,
                    ContactNo = draftOrder.ShippingAddress.ContactNo,
                    AddressType = Global.AddressType.Shipping
                };

                await _context.Address.AddAsync(sAddress);
                _context.SaveChanges();

                //creating orderAddress
                var data = _context.Address.Where(x => x.ContactEmail == draftOrder.BillingAddress.ContactEmail).FirstOrDefault();
                var data1 = _context.Address.Where(x => x.ContactEmail == draftOrder.ShippingAddress.ContactEmail).FirstOrDefault();

                var orderAddress = new OrderAddress()
                {
                    OrderId = getOrder.OrderId,
                    BillingAddressId = data.AddressId,
                    ShippingAddressId = data1.AddressId
                };

                await _context.OrderAddress.AddAsync(orderAddress);
                _context.SaveChanges();

                return new response { Data = "", Message = "Draft Added Successfully", Status = "Success" };
            }
            catch (Exception ex)
            {
                return new response { Data = ex.Message.ToString(), Message = "Something went Wrong!!!", Status = "Error" };
            }
        }

        //GetOrders(filters)
        public async Task<response> GetFilterdOrders(OrderFilter filter)
        {
            try
            {
                var TodaysDate = DateTime.Now;
                if (filter.fromDate == null)                             //Check fromDate is null
                {
                    if (TodaysDate.Day < 5)                             //Check today date is less than 5 if true
                    {
                        filter.fromDate = TodaysDate.AddMonths(-1);    //get the from Date is todays date and get the previous month
                    }
                    else
                    {
                        filter.fromDate = TodaysDate;                 //else the from Date is todays date and month
                    }
                }
                if (filter.toDate == null)                            //Check toDate is null 
                {
                    filter.toDate = TodaysDate;                       //get the todays date and month
                }
                response response = new response();
                List<Order> orders = await _context.Orders.ToListAsync();
                List<OrderItem> orderItems = await _context.OrderItems.ToListAsync();
                List<OrderAddress> OrderAddress = await _context.OrderAddress.ToListAsync();
                List<address> AddressList = await _context.Address.ToListAsync();
               // List<Product> ProductList = await _context.Products.ToListAsync();

                var filterdData = (from o in orders
                                   join oi in orderItems on o.OrderId equals oi.OrderId
                                   join oa in OrderAddress on o.OrderId equals oa.OrderId
                                   join a in AddressList on oa.ShippingAddressId equals a.AddressId
                                   join p in orderItems on oi.ProductId equals p.ProductId
                                   where
                                   (o.OrderDate.Date >= filter.fromDate.Value.Date && o.OrderDate.Date <= filter.toDate.Value.Date) ||
                                   o.StatusType.ToString().Equals(filter.statusType.ToString()) ||
                                   (o.CustomerName == filter.customerName ||
                                   o.CustomerEmail == filter.customerEmail) ||
                                   o.IsActive == filter.isActive 
                                   select new
                                   {
                                       o.OrderId,
                                       o.Note,
                                       o.CustomerName,
                                       o.CustomerEmail,                  
                                       Status = Convert(o.StatusType).ToString(),
                                       o.TotalAmount,
                                       adddress = string.Join(',', a.HouseNo, a.City, a.State, a.Country, a.ZipCode)
                                   }).Distinct();

                response.Data = filterdData.ToList();
                response.Message = "Success";
                response.Status = "Success";
                return response;
            }
            catch (Exception ex)
            {
                return new response { Data = ex.Message.ToString(), Message = "Exception", Status = "Error" };
            }

        }
       
        private response UpdateStatusOnDb(int OrderId, Global.status status)
        {
            response response = new response();
            var isExistData = _context.Orders.Where(x => x.OrderId == OrderId).ToList();
            isExistData.ForEach(x =>
            {
                x.StatusType = status;
                _context.Orders.Update(x);
            });
            _context.SaveChanges();

            response.Data = "";
            response.Message = "Status updated Successfully";
            response.Status = "Success";
            return response;
        }

        private Global.status Convert(Global.status status)
        {
            return (Global.status)Enum.ToObject(typeof(Global.status), status);
        }

    }
}
