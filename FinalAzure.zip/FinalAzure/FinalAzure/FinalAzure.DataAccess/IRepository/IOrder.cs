﻿using FinalAzure.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalAzure.DataAccess.IRepository
{
    public interface IOrder
    {
        public Task<response> UpdateStatus(int OrderId, Global.status status);
        public Task<response> AddDraftOrder(DraftOrder draftOrder);
        public Task<response> GetFilterdOrders(OrderFilter order);
    }
}
