﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalAzure.Models.Models
{
    public class OrderItem
    {
        public int OrderItemId { get; set; }
        public int Qty { get; set; }
        public int price { get; set; }
        public bool isActive { get; set; }
        [ForeignKey("Order")]
        public int OrderId { get; set; }
        [ForeignKey("Product")]
        public int ProductId { get; set; }
    }
}
