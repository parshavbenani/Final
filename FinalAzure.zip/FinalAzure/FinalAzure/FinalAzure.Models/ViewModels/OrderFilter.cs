﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static FinalAzure.Models.ViewModels.Global;

namespace FinalAzure.Models.ViewModels
{
    public class OrderFilter
    {
        public DateTime? fromDate { get; set; }
        public DateTime? toDate { get; set; } = DateTime.Now;

        public status? statusType { get; set; }
        public string? customerName { get; set; }
        public string? customerEmail { get; set; }
        public bool? isActive { get; set; }
        public int? productId { get; set; }
    }
}
